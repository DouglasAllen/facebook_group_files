#!/usr/bin/env ruby

for i in 1..12
  for j in 1..12
    print i.to_s + ' x ' + j.to_s + ' = ', j * i, "\n"
  end
end
