#!/usr/bin/env ruby

sprintf( "Hello, %s", "Matz!" ) # => "Hello, Matz!"
