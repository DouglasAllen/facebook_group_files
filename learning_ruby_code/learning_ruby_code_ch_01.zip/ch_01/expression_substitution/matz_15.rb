#!/usr/bin/env ruby
# a nice greeting for Matz
person = "Matz!"
puts "Hello, #{person}" # => Hello, Matz!
