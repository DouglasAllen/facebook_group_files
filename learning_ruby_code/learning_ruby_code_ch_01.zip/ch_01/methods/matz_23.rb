#!/usr/bin/env ruby

def hello
  puts "Hello, Matz!"
end

hello # => Hello, Matz!
