#!/usr/bin/env ruby

[ "Hello, ", "Matz!" ].each { |e| print e }
