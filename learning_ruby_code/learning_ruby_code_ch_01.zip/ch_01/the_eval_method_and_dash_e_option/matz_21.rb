#!/usr/bin/env ruby

eval "puts 'Hello, Matz!'" # => Hello, Matz!
