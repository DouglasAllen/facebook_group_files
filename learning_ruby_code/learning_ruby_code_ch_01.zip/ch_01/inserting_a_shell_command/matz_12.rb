#!/usr/bin/env ruby
# a nice greeting for Matz
puts "Hey, Matz, I'm running " + `ruby --version`
