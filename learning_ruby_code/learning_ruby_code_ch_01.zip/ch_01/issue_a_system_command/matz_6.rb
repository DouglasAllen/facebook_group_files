#!/usr/bin/env ruby
# a nice greeting for Matz
system "echo", "Hello,", "Matz!"
