#!/usr/bin/env ruby
# a nice greeting for Matz
puts "Hello, " * 3 + "Matz!"
