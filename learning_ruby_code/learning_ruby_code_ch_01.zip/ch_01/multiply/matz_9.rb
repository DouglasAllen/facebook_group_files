#!/usr/bin/env ruby
# a nice greeting for Matz
puts "Hello, Matz! " * 3
