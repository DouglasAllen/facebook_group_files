#!/usr/local/bin/ruby
puts "Hello, Matz!"
