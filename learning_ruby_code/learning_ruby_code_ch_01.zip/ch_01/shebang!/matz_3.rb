#!/usr/local/bin/ruby
# a nice greeting for Matz
puts "Hello, Matz!"
