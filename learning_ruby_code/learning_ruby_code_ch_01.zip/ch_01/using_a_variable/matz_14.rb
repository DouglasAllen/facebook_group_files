#!/usr/bin/env ruby
# a nice greeting for Matz
hi = "Hello, "
person = "Matz!"
puts hi + person # => Hello, Matz!
