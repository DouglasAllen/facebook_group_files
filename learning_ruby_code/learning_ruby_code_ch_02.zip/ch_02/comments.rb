#!/usr/bin/env ruby
# I am a comment. Just ignore me.

name = "Floydene Wallup" # ain't that a name to beat all

# This is a comment.
# This is a comment, too.
# This is a comment, too.
# I said that already.

=begin
This is a comment.
This is a comment, too.
This is a comment, too.
I said that already.
=end
