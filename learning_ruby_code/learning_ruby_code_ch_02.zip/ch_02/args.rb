#!/usr/bin/env ruby

def repeat( word, times )
  puts word * times
end

repeat( "Hello! ", 3) # => Hello! Hello! Hello!
repeat "Good-bye! ", 4 # => Good-bye! Good-bye! Good-bye! Good-bye! 
