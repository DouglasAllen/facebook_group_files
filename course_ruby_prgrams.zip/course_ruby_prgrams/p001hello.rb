# p001hello.rb

=begin
  Ruby is an interpreted language
  Source file has .rb extension
  Free format and case sensitive
  No statement delimiters
  Two types of comments
  String literals in single or double quotes
=end
puts 'Hello'