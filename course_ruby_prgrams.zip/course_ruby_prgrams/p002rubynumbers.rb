# p002rubynumbers.rb

=begin
 Ruby Numbers
 Usual operators:
 + addition
 - subtraction
 * multiplication
 / division
=end

puts 1 + 2
puts 2 * 3
# Integer division
# When you do arithmetic with integers, you'll get integer answers
puts 3 / 2
puts 10 - 11
puts 1.5 / 2.6
# class hierarchy
# http://www.cs.mun.ca/~donald/slug/2003-10-16/presentation/img5.html