# p063xself4.rb
class S
  def S.x
    puts "Class method of class S"
    puts self
  end
end
S.x