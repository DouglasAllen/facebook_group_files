# p074hellotk.rb
require 'tk'
hello = TkRoot.new {title "Hello World"}
Tk.mainloop